const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "ieeevisTweets"; // adjust if your DB name differs

async function main() {
  // Connect to MongoDB
  const mongo = new MongoClient(MONGO_URL);
  await mongo.connect();
  const db = mongo.db(DB_NAME);
  const tweets = db.collection("tweets");

  // Connect to Redis
  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error", err));
  await redis.connect();

  // Delete old set if exists
  await redis.del("screen_names");

  // Query all tweets and add each screen_name to the set
  const cursor = tweets.find({});
  for await (const doc of cursor) {
    const screenName = doc.user && doc.user.screen_name;
    if (screenName) {
      await redis.sAdd("screen_names", screenName);
    }
  }

  // Get the number of distinct users
  const distinctCount = await redis.sCard("screen_names");
  console.log(`There are ${distinctCount} distinct users`);

  // Cleanup
  await redis.quit();
  await mongo.close();
}

main().catch(console.error);
