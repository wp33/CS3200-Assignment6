const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "ieeevisTweets"; // adjust if your DB name differs

async function main() {
  // Connect to MongoDB
  const mongo = new MongoClient(MONGO_URL);
  await mongo.connect();
  const db = mongo.db(DB_NAME);
  const tweets = db.collection("tweets");

  // Connect to Redis
  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error", err));
  await redis.connect();

  // Initialize favoritesSum to 0
  await redis.set("favoritesSum", 0);

  // Query all tweets and increment by each tweet's favorite_count
  const cursor = tweets.find({});
  for await (const doc of cursor) {
    const favCount = doc.favorite_count || 0;
    if (favCount > 0) {
      await redis.incrBy("favoritesSum", favCount);
    }
  }

  // Get final sum and print
  const total = await redis.get("favoritesSum");
  console.log(`The total number of favorites is ${total}`);

  // Cleanup
  await redis.quit();
  await mongo.close();
}

main().catch(console.error);
