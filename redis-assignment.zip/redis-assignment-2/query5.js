const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "ieeevisTweets"; // adjust if your DB name differs

async function main() {
  // Connect to MongoDB
  const mongo = new MongoClient(MONGO_URL);
  await mongo.connect();
  const db = mongo.db(DB_NAME);
  const tweets = db.collection("tweets");

  // Connect to Redis
  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error", err));
  await redis.connect();

  // Query all tweets
  const cursor = tweets.find({});
  for await (const doc of cursor) {
    const screenName = doc.user && doc.user.screen_name;
    const tweetId = doc.id_str || String(doc.id);

    if (!screenName || !tweetId) continue;

    // Push the tweet id into the user's list: tweets:<screen_name>
    const listKey = `tweets:${screenName}`;
    await redis.rPush(listKey, tweetId);

    // Store tweet details as a hash: tweet:<tweet_id>
    const hashKey = `tweet:${tweetId}`;
    const tweetData = {
      user_name: screenName,
      text: doc.text || "",
      created_at: doc.created_at || "",
      retweet_count: String(doc.retweet_count || 0),
      favorite_count: String(doc.favorite_count || 0),
    };
    await redis.hSet(hashKey, tweetData);
  }

  console.log("Tweet structures created in Redis.");

  // --- Demo: retrieve tweets for a specific user ---
  // Get all keys matching tweets:*
  const userKeys = [];
  for await (const key of redis.scanIterator({ MATCH: "tweets:*", COUNT: 100 })) {
    userKeys.push(key);
  }

  if (userKeys.length > 0) {
    // Pick the first user found as a demo
    const sampleKey = userKeys[0];
    const sampleUser = sampleKey.replace("tweets:", "");

    const tweetIds = await redis.lRange(sampleKey, 0, -1);
    console.log(`\nUser @${sampleUser} has ${tweetIds.length} tweet(s):`);

    // Print the first tweet's details as an example
    if (tweetIds.length > 0) {
      const firstTweetId = tweetIds[0];
      const tweetInfo = await redis.hGetAll(`tweet:${firstTweetId}`);
      console.log(`  Tweet ID: ${firstTweetId}`);
      console.log(`  Text: ${tweetInfo.text}`);
      console.log(`  Created at: ${tweetInfo.created_at}`);
      console.log(`  Favorites: ${tweetInfo.favorite_count}`);
      console.log(`  Retweets: ${tweetInfo.retweet_count}`);
    }
  }

  // Cleanup
  await redis.quit();
  await mongo.close();
}

main().catch(console.error);
