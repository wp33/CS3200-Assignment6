const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "ieeevisTweets"; // adjust if your DB name differs

async function main() {
  // Connect to MongoDB
  const mongo = new MongoClient(MONGO_URL);
  await mongo.connect();
  const db = mongo.db(DB_NAME);
  const tweets = db.collection("tweets");

  // Connect to Redis
  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error", err));
  await redis.connect();

  // Delete old sorted set if exists
  await redis.del("leaderboard");

  // Query all tweets and increment score for each user
  const cursor = tweets.find({});
  for await (const doc of cursor) {
    const screenName = doc.user && doc.user.screen_name;
    if (screenName) {
      await redis.zIncrBy("leaderboard", 1, screenName);
    }
  }

  // Get top 10 users with highest tweet counts (descending order)
  const top10 = await redis.zRangeWithScores("leaderboard", 0, 9, {
    REV: true,
  });

  console.log("Top 10 users with the most tweets:");
  top10.forEach((entry, index) => {
    console.log(`  ${index + 1}. ${entry.value}: ${entry.score} tweets`);
  });

  // Cleanup
  await redis.quit();
  await mongo.close();
}

main().catch(console.error);
