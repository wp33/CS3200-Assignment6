const { MongoClient } = require("mongodb");
const { createClient } = require("redis");

const MONGO_URL = "mongodb://localhost:27017";
const DB_NAME = "ieeevisTweets"; // adjust if your DB name differs

async function main() {
  // Connect to MongoDB
  const mongo = new MongoClient(MONGO_URL);
  await mongo.connect();
  const db = mongo.db(DB_NAME);
  const tweets = db.collection("tweets");

  // Connect to Redis
  const redis = createClient();
  redis.on("error", (err) => console.error("Redis Client Error", err));
  await redis.connect();

  // Initialize tweetCount to 0
  await redis.set("tweetCount", 0);

  // Query all tweets and increment tweetCount for each one
  const cursor = tweets.find({});
  for await (const doc of cursor) {
    await redis.incr("tweetCount");
  }

  // Get final count and print
  const count = await redis.get("tweetCount");
  console.log(`There were ${count} tweets`);

  // Cleanup
  await redis.quit();
  await mongo.close();
}

main().catch(console.error);
